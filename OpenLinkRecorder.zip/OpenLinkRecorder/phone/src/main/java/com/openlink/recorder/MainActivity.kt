package com.openlink.recorder

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Date

private val Bg = Color(0xFF06080C)
private val Surface1 = Color(0xFF0E131A)
private val Surface2 = Color(0xFF151C26)
private val Cyan = Color(0xFF22D3EE)
private val TextHi = Color(0xFFE6EDF3)
private val TextLo = Color(0xFF8B98A9)
private val Rec = Color(0xFFFF5470)

class PlayerController(private val ctx: Context) {
    var playingId by mutableStateOf<Long?>(null)
    private var mp: MediaPlayer? = null

    fun toggle(r: Recording) {
        if (playingId == r.id) { stop(); return }
        stop()
        val p = MediaPlayer()
        try {
            p.setDataSource(ctx, r.uri)
            p.setOnCompletionListener { stop() }
            p.setOnErrorListener { _, _, _ -> stop(); true }
            p.prepare()
            p.start()
            mp = p
            playingId = r.id
        } catch (e: Exception) {
            try { p.release() } catch (_: Exception) {}
            playingId = null
        }
    }

    fun stop() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        playingId = null
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var player: PlayerController

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasMic()) RecorderService.send(this, RecorderService.ACTION_ARM)
        }

    private fun hasMic() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(p.toTypedArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        player = PlayerController(this)
        if (!hasMic()) requestPerms()

        // Poll connected watches while visible.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    val names = try {
                        Wearable.getNodeClient(applicationContext).connectedNodes.await().map { it.displayName }
                    } catch (_: Exception) { emptyList() }
                    RecorderStore.update { it.copy(watchNames = names) }
                    delay(4000)
                }
            }
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Surface1)) {
                Screen(
                    player = player,
                    onToggle = {
                        if (!hasMic()) requestPerms()
                        else if (RecorderStore.state.value.status == Status.RECORDING)
                            RecorderService.send(this, RecorderService.ACTION_STOP)
                        else RecorderService.send(this, RecorderService.ACTION_START)
                    },
                    onDisarm = { RecorderService.send(this, RecorderService.ACTION_DISARM) },
                    onShare = { r ->
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "audio/mp4"
                            putExtra(Intent.EXTRA_STREAM, r.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(i, "Share recording"))
                    }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (hasMic()) {
            try { RecorderService.send(this, RecorderService.ACTION_ARM) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        player.stop()
        super.onDestroy()
    }
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@Composable
private fun Screen(
    player: PlayerController,
    onToggle: () -> Unit,
    onDisarm: () -> Unit,
    onShare: (Recording) -> Unit
) {
    val ctx = LocalContext.current
    val st by RecorderStore.state.collectAsState()
    val recording = st.status == Status.RECORDING
    var recs by remember { mutableStateOf(emptyList<Recording>()) }
    var toDelete by remember { mutableStateOf<Recording?>(null) }

    LaunchedEffect(st.savedTick) {
        recs = withContext(Dispatchers.IO) { Recordings.list(ctx) }
        delay(2000) // media scan fills in duration shortly after saving
        recs = withContext(Dispatchers.IO) { Recordings.list(ctx) }
    }
    LaunchedEffect(recording) { if (recording) player.stop() }

    val batteryOk = remember {
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth().background(Bg).systemBarsPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("OpenLink", color = Cyan, fontSize = 13.sp, letterSpacing = 4.sp, fontWeight = FontWeight.SemiBold)
                Text("Recorder", color = TextHi, fontSize = 30.sp, fontWeight = FontWeight.Light)
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.13f), Surface1), radius = 700f))
                    .border(BorderStroke(1.dp, Cyan.copy(alpha = 0.18f)), RoundedCornerShape(28.dp))
                    .padding(vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                StatusChip(recording, st.armed)
                Spacer(Modifier.height(10.dp))
                Timer(st)
                Spacer(Modifier.height(18.dp))
                RecordButton(recording, onToggle)
                Spacer(Modifier.height(16.dp))
                val line = st.message ?: st.lastSaved?.let { "Saved: $it" } ?: "Tap to record, or use your watch"
                Text(
                    line, color = if (st.message != null) Rec else TextLo, fontSize = 13.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp)
                )
                if (st.armed && !recording) {
                    TextButton(onClick = onDisarm) { Text("Turn off watch standby", color = TextLo, fontSize = 12.sp) }
                }
            }
        }
        item {
            val connected = st.watchNames.isNotEmpty()
            InfoCard(
                title = if (connected) "Watch connected" else "Watch not connected",
                body = if (connected) st.watchNames.joinToString() + "\nWatch START/STOP controls this phone."
                else "Recording on the phone works regardless. The watch reconnects automatically.",
                dot = if (connected) Cyan else TextLo
            )
        }
        if (!batteryOk) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surface1).padding(16.dp)
                ) {
                    Text("Improve watch reliability", color = TextHi, fontWeight = FontWeight.Medium)
                    Text(
                        "Exempt OpenLink from battery optimization so Samsung doesn't put it to sleep.",
                        color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }) { Text("Open battery settings", color = Cyan) }
                }
            }
        }
        item {
            Text("RECORDINGS", color = TextLo, fontSize = 12.sp, letterSpacing = 3.sp,
                modifier = Modifier.padding(top = 8.dp))
        }
        if (recs.isEmpty()) {
            item { Text("No recordings yet.", color = TextLo, fontSize = 14.sp) }
        }
        items(recs, key = { it.id }) { r ->
            RecordingRow(
                r, playing = player.playingId == r.id, canPlay = !recording,
                onPlay = { player.toggle(r) }, onShare = { onShare(r) }, onDelete = { toDelete = r }
            )
        }
    }

    toDelete?.let { r ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = Surface2,
            title = { Text("Delete recording?", color = TextHi) },
            text = { Text(r.name, color = TextLo) },
            confirmButton = {
                TextButton(onClick = {
                    if (player.playingId == r.id) player.stop()
                    Recordings.delete(ctx, r)
                    recs = recs.filter { it.id != r.id }
                    toDelete = null
                }) { Text("Delete", color = Rec) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel", color = TextLo) } }
        )
    }
}

@Composable
private fun StatusChip(recording: Boolean, armed: Boolean) {
    val (label, color) = when {
        recording -> "RECORDING" to Rec
        armed -> "STANDBY · WATCH READY" to Cyan
        else -> "IDLE" to TextLo
    }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Bg.copy(alpha = 0.6f)).padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text(label, color = color, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Timer(st: RecState) {
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) { while (true) { now = SystemClock.elapsedRealtime(); delay(250) } }
    val ms = if (st.status == Status.RECORDING) (now - st.startedElapsed).coerceAtLeast(0) else 0L
    Text(
        fmt(ms), color = TextHi, fontSize = 64.sp, fontWeight = FontWeight.ExtraLight,
        fontFeatureSettings = "tnum"
    )
}

@Composable
private fun RecordButton(recording: Boolean, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "pulse")
    val scale by inf.animateFloat(1f, 1.3f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "s")
    val alpha by inf.animateFloat(0.55f, 0f, infiniteRepeatable(tween(1500), RepeatMode.Restart), label = "a")
    Box(Modifier.size(190.dp), contentAlignment = Alignment.Center) {
        if (recording) Box(Modifier.size(150.dp).scale(scale).border(2.dp, Cyan.copy(alpha = alpha), CircleShape))
        Box(
            Modifier.size(150.dp).clip(CircleShape).background(Surface2)
                .border(2.dp, Cyan, CircleShape)
                .semantics { contentDescription = if (recording) "Stop recording" else "Start recording" }
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (recording) Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Cyan))
            else Box(Modifier.size(84.dp).clip(CircleShape).background(Cyan))
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, dot: Color) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surface1).padding(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.padding(top = 6.dp).size(8.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = TextHi, fontWeight = FontWeight.Medium)
            Text(body, color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun RecordingRow(
    r: Recording, playing: Boolean, canPlay: Boolean,
    onPlay: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    val date = DateFormat.getMediumDateFormat(ctx).format(Date(r.addedSec * 1000)) + " " +
        DateFormat.getTimeFormat(ctx).format(Date(r.addedSec * 1000))
    val meta = (if (r.durationMs > 0) fmt(r.durationMs) + " · " else "") + "%.1f MB".format(r.size / 1_048_576.0)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surface1)
            .border(BorderStroke(1.dp, if (playing) Cyan.copy(alpha = 0.5f) else Color.Transparent), RoundedCornerShape(20.dp))
            .padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp)
    ) {
        Text(date, color = TextHi, fontWeight = FontWeight.Medium)
        Text("$meta · ${r.name}", color = TextLo, fontSize = 12.sp, maxLines = 1)
        Row {
            TextButton(onClick = onPlay, enabled = canPlay) {
                Text(if (playing) "Stop" else "Play", color = if (canPlay) Cyan else TextLo)
            }
            TextButton(onClick = onShare) { Text("Share", color = TextLo) }
            TextButton(onClick = onDelete) { Text("Delete", color = TextLo) }
        }
    }
}
