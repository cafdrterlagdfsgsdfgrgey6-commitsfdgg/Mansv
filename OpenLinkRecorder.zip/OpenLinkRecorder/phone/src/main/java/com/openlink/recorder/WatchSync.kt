package com.openlink.recorder

import android.content.Context
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable

object WatchSync {
    /** Publishes the current recording state as a persistent, urgent DataItem. The watch gets it
     *  immediately when connected and automatically after reconnecting. */
    fun publish(ctx: Context) {
        val s = RecorderStore.state.value
        val req = PutDataMapRequest.create(Protocol.PATH_STATE).apply {
            dataMap.putString("status", s.status.name)
            dataMap.putBoolean("armed", s.armed)
            dataMap.putLong("startedWall", s.startedWall)
            dataMap.putString("message", s.message ?: "")
            dataMap.putLong("updated", System.currentTimeMillis())
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        try {
            Wearable.getDataClient(ctx.applicationContext).putDataItem(req)
        } catch (_: Exception) { /* Play services unavailable: phone recording is unaffected */ }
    }
}
