package com.openlink.recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground microphone service. It is started ("armed") once while the app is visible, which gives
 * it the OS permission to use the mic; after that the watch can start/stop recording at any time.
 * Recording lives entirely in this service, so a watch disconnect cannot affect it.
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_ARM = "com.openlink.recorder.ARM"
        const val ACTION_START = "com.openlink.recorder.START"
        const val ACTION_STOP = "com.openlink.recorder.STOP"
        const val ACTION_DISARM = "com.openlink.recorder.DISARM"
        private const val CHANNEL = "recorder"
        private const val NOTIF_ID = 42

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, RecorderService::class.java).setAction(action)
            if (action == ACTION_STOP) ctx.startService(i) else ContextCompat.startForegroundService(ctx, i)
        }
    }

    private var recorder: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: android.net.Uri? = null
    private var fileName: String = ""
    private var wakeLock: PowerManager.WakeLock? = null
    private var foregroundOk = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Recording", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ARM -> if (ensureForeground()) {
                RecorderStore.update { it.copy(armed = true, message = null) }
                WatchSync.publish(this)
            }
            ACTION_START -> startRecording()
            ACTION_STOP -> stopRecording()
            ACTION_DISARM -> {
                stopRecording()
                foregroundOk = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> if (!foregroundOk) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun ensureForeground(): Boolean {
        if (foregroundOk) return true
        return try {
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(NOTIF_ID, buildNotification())
            foregroundOk = true
            true
        } catch (e: Exception) {
            fail("Open OpenLink Recorder on the phone once, then try again")
            stopSelf()
            false
        }
    }

    private fun startRecording() {
        if (recorder != null) { WatchSync.publish(this); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            fail("Microphone permission missing on phone"); if (!foregroundOk) stopSelf(); return
        }
        if (!ensureForeground()) return
        try {
            begin()
        } catch (e: Exception) {
            cleanupFailedStart()
            fail("Could not start recording: ${e.message ?: "unknown error"}")
            return
        }
        RecorderStore.update {
            it.copy(status = Status.RECORDING, armed = true, message = null,
                startedWall = System.currentTimeMillis(), startedElapsed = SystemClock.elapsedRealtime())
        }
        refreshNotification()
        WatchSync.publish(this)
    }

    private fun begin() {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        fileName = "OpenLink_$stamp.m4a"
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, Recordings.REL_PATH)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val u = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create file")
        uri = u
        val p = contentResolver.openFileDescriptor(u, "w") ?: throw IllegalStateException("Could not open file")
        pfd = p
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioEncodingBitRate(128_000)
        r.setAudioSamplingRate(44_100)
        r.setAudioChannels(1)
        r.setOutputFile(p.fileDescriptor)
        r.setOnErrorListener { _, what, _ ->
            stopRecording("Recording stopped by system (error $what)")
        }
        try {
            r.prepare()
            r.start()
        } catch (e: Exception) {
            try { r.release() } catch (_: Exception) {}
            throw e
        }
        recorder = r
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OpenLink:rec").apply {
            acquire(12 * 60 * 60 * 1000L)
        }
    }

    private fun cleanupFailedStart() {
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        uri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
        uri = null
    }

    private fun stopRecording(errorMsg: String? = null) {
        val r = recorder
        if (r == null) { WatchSync.publish(this); return }
        recorder = null
        var ok = true
        try { r.stop() } catch (e: RuntimeException) { ok = false }
        try { r.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        val u = uri
        uri = null
        if (u != null) {
            try {
                if (ok) contentResolver.update(u, ContentValues().apply {
                    put(MediaStore.Audio.Media.IS_PENDING, 0)
                }, null, null)
                else contentResolver.delete(u, null, null)
            } catch (_: Exception) {}
        }
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
        RecorderStore.update {
            it.copy(
                status = if (errorMsg != null) Status.ERROR else Status.IDLE,
                startedWall = 0L, startedElapsed = 0L,
                lastSaved = if (ok) fileName else it.lastSaved,
                savedTick = it.savedTick + 1,
                message = errorMsg ?: if (ok) null else "Recording was too short and was discarded"
            )
        }
        if (foregroundOk) refreshNotification()
        WatchSync.publish(this)
    }

    private fun fail(msg: String) {
        RecorderStore.update { it.copy(status = Status.ERROR, message = msg) }
        WatchSync.publish(this)
    }

    private fun buildNotification(): Notification {
        val rec = recorder != null
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val act = PendingIntent.getService(
            this, 1,
            Intent(this, RecorderService::class.java).setAction(if (rec) ACTION_STOP else ACTION_DISARM),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle(if (rec) "Recording" else "OpenLink Recorder")
            .setContentText(if (rec) "Recording from the phone microphone" else "Standby: your watch can start recording")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, if (rec) "Stop" else "Turn off standby", act)
        if (rec) {
            val s = RecorderStore.state.value
            b.setUsesChronometer(true).setShowWhen(true)
                .setWhen(System.currentTimeMillis() - (SystemClock.elapsedRealtime() - s.startedElapsed))
        }
        return b.build()
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    override fun onDestroy() {
        stopRecording()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        RecorderStore.update { it.copy(armed = false, status = Status.IDLE, startedWall = 0L) }
        WatchSync.publish(this)
        super.onDestroy()
    }
}
