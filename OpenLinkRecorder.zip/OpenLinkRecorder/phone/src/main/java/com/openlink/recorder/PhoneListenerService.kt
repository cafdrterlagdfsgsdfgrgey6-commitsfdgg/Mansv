package com.openlink.recorder

import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/** Receives watch commands, even when the app UI is closed. */
class PhoneListenerService : WearableListenerService() {

    override fun onMessageReceived(event: MessageEvent) {
        val s = RecorderStore.state.value
        when (event.path) {
            Protocol.PATH_START -> {
                if (s.status == Status.RECORDING) { WatchSync.publish(this); return }
                try {
                    RecorderService.send(this, RecorderService.ACTION_START)
                } catch (e: Exception) {
                    RecorderStore.update {
                        it.copy(status = Status.ERROR, message = "Open OpenLink Recorder on the phone once, then try again")
                    }
                    WatchSync.publish(this)
                }
            }
            Protocol.PATH_STOP -> {
                if (s.status != Status.RECORDING) { WatchSync.publish(this); return }
                try { RecorderService.send(this, RecorderService.ACTION_STOP) } catch (_: Exception) {}
            }
            Protocol.PATH_SYNC -> WatchSync.publish(this)
        }
    }
}
