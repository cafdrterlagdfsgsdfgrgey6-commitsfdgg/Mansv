package com.openlink.recorder

/** Data Layer contract shared by phone and watch (the watch module has an identical copy). */
object Protocol {
    const val CAP_PHONE = "openlink_recorder_phone"
    const val PATH_START = "/cmd/start"
    const val PATH_STOP = "/cmd/stop"
    const val PATH_SYNC = "/cmd/sync"
    const val PATH_STATE = "/state"
}
