package com.openlink.recorder

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Recording(
    val id: Long, val uri: Uri, val name: String,
    val durationMs: Long, val size: Long, val addedSec: Long
)

object Recordings {
    const val REL_PATH = "Music/OpenLinkRecorder"

    fun list(ctx: Context): List<Recording> {
        val out = ArrayList<Recording>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?", arrayOf("$REL_PATH%"),
                "${MediaStore.Audio.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out += Recording(
                        id, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "recording", c.getLong(2), c.getLong(3), c.getLong(4)
                    )
                }
            }
        } catch (_: Exception) { }
        return out
    }

    fun delete(ctx: Context, r: Recording) {
        try { ctx.contentResolver.delete(r.uri, null, null) } catch (_: Exception) { }
    }
}
