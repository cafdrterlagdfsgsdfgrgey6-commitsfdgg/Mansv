package com.openlink.recorder

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

enum class Status { IDLE, RECORDING, ERROR }

data class RecState(
    val status: Status = Status.IDLE,
    /** True while the foreground service is alive (standby or recording). */
    val armed: Boolean = false,
    val startedWall: Long = 0L,
    val startedElapsed: Long = 0L,
    val message: String? = null,
    val lastSaved: String? = null,
    val savedTick: Int = 0,
    val watchNames: List<String> = emptyList()
)

object RecorderStore {
    val state = MutableStateFlow(RecState())
    fun update(f: (RecState) -> RecState) = state.update(f)
}
