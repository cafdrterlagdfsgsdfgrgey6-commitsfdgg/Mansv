package com.openlink.recorder.wear

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Cyan = Color(0xFF22D3EE)
private val Rec = Color(0xFFFF5470)
private val Lo = Color(0xFF8B98A9)
private val Hi = Color(0xFFE6EDF3)
private val Dark = Color(0xFF151C26)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WatchRepo.init(applicationContext)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { WatchScreen() }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                WatchRepo.refresh(sync = true)
                while (true) {
                    delay(8000)
                    WatchRepo.refresh(sync = false)
                }
            }
        }
    }
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@Composable
private fun WatchScreen() {
    val st by WatchRepo.state.collectAsState()
    val recording = st.status == "RECORDING"
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(500) } }
    val elapsed = if (recording) (now - st.startedWall).coerceAtLeast(0) else 0L

    val statusText = when {
        st.pending -> "WORKING…"
        recording -> "● RECORDING"
        else -> "READY"
    }
    val footer = when {
        st.message != null -> st.message!!
        !st.reachable && recording -> "Phone out of range · last known"
        !st.reachable -> "Phone not connected"
        else -> "Phone connected"
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF05070A)), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 22.dp)
        ) {
            BasicText(
                statusText,
                style = TextStyle(color = if (recording) Rec else Cyan, fontSize = 11.sp, letterSpacing = 2.sp,
                    fontWeight = FontWeight.Medium)
            )
            BasicText(
                fmt(elapsed),
                style = TextStyle(color = Hi, fontSize = 36.sp, fontWeight = FontWeight.Light,
                    fontFeatureSettings = "tnum")
            )
            ActionButton(recording, !st.pending) { WatchRepo.command(start = !recording) }
            BasicText(
                footer,
                style = TextStyle(color = if (st.message != null) Rec else Lo, fontSize = 10.sp,
                    textAlign = TextAlign.Center),
                maxLines = 2
            )
        }
    }
}

@Composable
private fun ActionButton(recording: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "pulse")
    val scale by inf.animateFloat(1f, 1.22f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "s")
    val alpha by inf.animateFloat(0.55f, 0f, infiniteRepeatable(tween(1500), RepeatMode.Restart), label = "a")
    Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
        if (recording) Box(Modifier.size(80.dp).scale(scale).border(2.dp, Cyan.copy(alpha = alpha), CircleShape))
        Box(
            Modifier.size(80.dp).clip(CircleShape)
                .background(if (recording) Dark else Cyan)
                .border(2.dp, Cyan, CircleShape)
                .semantics { contentDescription = if (recording) "Stop recording on phone" else "Start recording on phone" }
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            BasicText(
                if (recording) "STOP" else "START",
                style = TextStyle(color = if (recording) Cyan else Color(0xFF031418), fontSize = 15.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            )
        }
    }
}
