package com.openlink.recorder.wear

import android.app.Application

class WatchApp : Application() {
    override fun onCreate() {
        super.onCreate()
        WatchRepo.init(this)
    }
}
