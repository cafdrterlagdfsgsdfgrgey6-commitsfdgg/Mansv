package com.openlink.recorder.wear

object Protocol {
    const val CAP_PHONE = "openlink_recorder_phone"
    const val PATH_START = "/cmd/start"
    const val PATH_STOP = "/cmd/stop"
    const val PATH_SYNC = "/cmd/sync"
    const val PATH_STATE = "/state"
}
