package com.openlink.recorder.wear

import android.content.Context
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator
import com.google.android.gms.wearable.CapabilityClient
import com.google.android.gms.wearable.DataMap
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.Node
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class WatchState(
    val status: String = "IDLE",      // IDLE | RECORDING | ERROR (as reported by the phone)
    val startedWall: Long = 0L,
    val armed: Boolean = false,
    val message: String? = null,
    val reachable: Boolean = false,
    val pending: Boolean = false,
    val hasState: Boolean = false
)

/** The watch only ever sends commands and mirrors state published by the phone. No audio, ever. */
object WatchRepo {
    val state = MutableStateFlow(WatchState())
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var pendingJob: Job? = null

    fun init(ctx: Context) { app = ctx.applicationContext }

    /** Called from the DataLayer listener (any thread). Reads the map synchronously first. */
    fun apply(map: DataMap) {
        val status = map.getString("status") ?: "IDLE"
        val started = map.getLong("startedWall")
        val armed = map.getBoolean("armed")
        val msg = map.getString("message")?.ifEmpty { null }
        scope.launch {
            val prev = state.value
            state.update {
                it.copy(status = status, startedWall = started, armed = armed, message = msg,
                    pending = false, hasState = true, reachable = true)
            }
            pendingJob?.cancel()
            if (prev.hasState && prev.status != status) buzz()
        }
    }

    private fun buzz() {
        try {
            app.getSystemService(Vibrator::class.java)
                ?.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private suspend fun phoneNodes(): List<Node> {
        val cap = Wearable.getCapabilityClient(app)
            .getCapability(Protocol.CAP_PHONE, CapabilityClient.FILTER_REACHABLE).await()
        val nodes = cap.nodes.toList()
        return if (nodes.isNotEmpty()) nodes else Wearable.getNodeClient(app).connectedNodes.await()
    }

    private suspend fun sendAll(path: String): Boolean {
        val nodes = try { phoneNodes() } catch (_: Exception) { return false }
        var ok = false
        for (n in nodes) {
            try {
                Wearable.getMessageClient(app).sendMessage(n.id, path, ByteArray(0)).await()
                ok = true
            } catch (_: Exception) {}
        }
        return ok
    }

    private suspend fun fetchStored() {
        val buf = Wearable.getDataClient(app).getDataItems(Uri.parse("wear://*/state")).await()
        try {
            for (item in buf) {
                if (item.uri.path == Protocol.PATH_STATE) apply(DataMapItem.fromDataItem(item).dataMap)
            }
        } finally { buf.release() }
    }

    /** Re-check reachability, load the last published state, optionally ask the phone to re-publish. */
    fun refresh(sync: Boolean) {
        scope.launch {
            val nodes = try { phoneNodes() } catch (_: Exception) { emptyList() }
            state.update { it.copy(reachable = nodes.isNotEmpty()) }
            try { fetchStored() } catch (_: Exception) {}
            if (sync && nodes.isNotEmpty()) sendAll(Protocol.PATH_SYNC)
        }
    }

    fun command(start: Boolean) {
        state.update { it.copy(pending = true, message = null) }
        pendingJob?.cancel()
        pendingJob = scope.launch {
            val ok = sendAll(if (start) Protocol.PATH_START else Protocol.PATH_STOP)
            if (!ok) {
                state.update { it.copy(pending = false, reachable = false, message = "Phone not reachable") }
                return@launch
            }
            delay(6000)
            state.update { if (it.pending) it.copy(pending = false, message = "No response from phone") else it }
        }
    }
}
