package com.openlink.recorder.wear

import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.WearableListenerService

class WatchListenerService : WearableListenerService() {
    override fun onDataChanged(events: DataEventBuffer) {
        WatchRepo.init(applicationContext)
        for (e in events) {
            if (e.type == DataEvent.TYPE_CHANGED && e.dataItem.uri.path == Protocol.PATH_STATE) {
                WatchRepo.apply(DataMapItem.fromDataItem(e.dataItem).dataMap)
            }
        }
    }
}
