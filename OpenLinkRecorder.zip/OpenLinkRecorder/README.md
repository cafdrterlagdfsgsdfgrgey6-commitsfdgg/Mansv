# OpenLink Recorder (Android + Wear OS)

Phone mic recorder, remote-controlled by a single START/STOP button on a Galaxy Watch.
Kotlin, Jetpack Compose, Wear Data Layer (Bluetooth/Wi-Fi via Google Play services). No cloud, AI,
transcription, accounts, or paid APIs. The watch module has no RECORD_AUDIO permission and never uses its mic.

## Requirements
- Android Studio Koala (2024.1.2) or newer (JDK 17 is bundled)
- Samsung phone (Android 10+) paired to the Galaxy Watch 8 via the Galaxy Wearable app
- USB debugging on the phone; ADB debugging + Wireless debugging on the watch

## Build & install
1. Open this folder in Android Studio (File > Open) and let Gradle sync (it downloads Gradle 8.9 and dependencies).
2. **Phone:** connect via USB, choose run configuration `phone`, press Run.
3. **Watch:** Settings > About watch > Software info > tap *Software version* 5 times; then
   Settings > Developer options > turn on *ADB debugging* and *Wireless debugging* > *Pair new device*.
   In Android Studio: Device Manager > Pair Devices Using Wi-Fi (or `adb pair <ip:port>` then `adb connect <ip:port>`).
   Choose run configuration `wear`, select the watch, press Run.
4. Install both from the same computer/debug keystore (the Data Layer requires matching package name and signature).

## First run
1. Open **OpenLink Recorder** on the phone, allow Microphone and Notifications.
   The app enters *Standby* (persistent notification). This one-time "arming" is what lets Android 12+
   allow microphone use when the watch triggers a recording while the phone screen is off.
2. Settings > Apps > OpenLink Recorder > Battery > **Unrestricted** (Samsung otherwise may sleep the app).
3. Open **OpenLink** on the watch and tap START. Status and timer appear on both devices; the watch vibrates on state changes.

## Where recordings are
`Music/OpenLinkRecorder/OpenLink_YYYY-MM-DD_HH-mm-ss.m4a` (AAC, 44.1 kHz, mono, 128 kbps). They play in the app
and in any music/file app. The app can also share or delete them.

## How it works
- `RecorderService` (phone): foreground service (type microphone) using `MediaRecorder` writing through MediaStore.
  Recording lives entirely in this service, so a watch disconnect cannot interrupt it.
- Watch -> phone: `MessageClient` commands `/cmd/start`, `/cmd/stop`, `/cmd/sync`, delivered to
  `PhoneListenerService` even if the phone UI is closed. The watch finds the phone via a Capability.
- Phone -> watch: state is a persistent urgent `DataItem` (`/state`), so the watch updates instantly and
  re-syncs automatically on reconnect. The watch shows an error if the phone does not respond within 6 s.

## Limitations
- If the phone app was force-stopped or you tapped "Turn off standby", Android may block a background
  microphone start; the watch then shows "Open OpenLink Recorder on the phone once". Open the app to re-arm.
- Watch clock and phone clock are used for the elapsed timer; they are normally synced automatically.
- This code was written without access to Android build tooling; if Gradle reports a version issue,
  use Android Studio's suggested upgrade for the AGP/Kotlin version.
